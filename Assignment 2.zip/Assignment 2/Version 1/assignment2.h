#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <sys/time.h>

// Define a struct for the tree node
typedef struct Node {
    struct Node* left;
    struct Node* right;
    int size;
    int data;
} Node;

// Define a struct for the Random Binary Search Tree
typedef struct RandomBinarySearchTree {
    Node* root;
} RBST;

// Function to initialize RBST
RBST initRBST();

// Function to create a new tree node
Node* initNode(int data);

// Function to seed the random number generator
void seedClock();

// Function to flatten the tree into an array
void flattenTree(Node* node, Node** array, int* index);

// Function to insert a node into the tree
Node* insertNode(Node* node, int key);

// Function to shuffle the tree nodes
Node* shuffleTree(Node* node, Node** array, int first, int last, int init);

// Function to randomize the tree
void randomizeTree(Node* node, int size);

// Function to insert a key into RBST
void insertRBST(RBST* tree, int key);

// Function to free the nodes in the tree
void freeNodes(Node* node);

// Function to free the RBST
void freeRBST(RBST* tree);

// Function to print the tree in-order
void printRBST(Node* node);
