#include "assignment2.h"



RBST initRBST() {
    RBST newRBST;
    newRBST.root = NULL;
    return newRBST;
}

Node* initNode(int data) {
    Node* newNode = malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Malloc failure in initNode...\n");
        exit(1);
    }
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->size = 1;
    newNode->data = data;
    return newNode;
}

void seedClock() {
    struct timeval t1;
    gettimeofday(&t1, NULL);
    srand48(t1.tv_usec + t1.tv_sec);
}

void flattenTree(Node* node, Node** array, int* index) {
    if (node->left != NULL) {
        flattenTree(node->left, array, index);
    }
    array[*index] = node;
    (*index)++;
    if (node->right != NULL) {
        flattenTree(node->right, array, index);
    }
}

Node* insertNode(Node* node, int key) {
    if (node == NULL) {
        return initNode(key);
    }
    node->size++;
    if (key < node->data) {
        node->left = insertNode(node->left, key);
    } else {
        node->right = insertNode(node->right, key);
    }
    return node;
}

Node* shuffleTree(Node* node, Node** array, int first, int last, int init) {
    seedClock();
    int size = last - first;
    int index = first + drand48() * size;

    Node* newNode = NULL;

    if (init == 1) {
        newNode = initNode(array[index]->data);
    } else {
        newNode = insertNode(node, array[index]->data);
    }

    if (index > first) {
        newNode->left = shuffleTree(newNode->left, array, first, index - 1, 0);
    }

    if (index < last) {
        newNode->right = shuffleTree(newNode->right, array, index + 1, last, 0);
    }

    return newNode;
}

void randomizeTree(Node* node, int size) {
    seedClock();
    Node** array = malloc(sizeof(Node*) * size);
    if (array == NULL) {
        printf("Malloc failure in randomizeTree...\n");
        exit(1);
    }
    int index = 0;
    flattenTree(node, array, &index);

    freeNodes(node);

    node = shuffleTree(node, array, 0, size, 1);
    free(array);
}

void insertRBST(RBST* tree, int key) {
    tree->root = insertNode(tree->root, key);
}

void freeNodes(Node* node) {
    if (node != NULL) {
        freeNodes(node->left);
        freeNodes(node->right);
        free(node);
    }
}

void freeRBST(RBST* tree) {
    freeNodes(tree->root);
    tree->root = NULL;
}

void printRBST(Node* node) {
    if (node != NULL) {
        printRBST(node->left);
        printf("RBST: %d\n", node->data);
        printRBST(node->right);
    }
}
