#include "assignment2.h"


int main(void) 
{
    RBST this = initRBST();
    insertRBST(&this, 3);
    insertRBST(&this, 1);
    insertRBST(&this, 8);
    insertRBST(&this, 9);
    insertRBST(&this, 10);
    insertRBST(&this, 2);
    printRBST(this.root);

    randomizeTree(this.root, 6);

    printRBST(this.root);

    freeRBST(&this);

    return 0;
}