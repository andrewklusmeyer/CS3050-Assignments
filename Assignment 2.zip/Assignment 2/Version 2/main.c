#include "assignment2.h"

int main() 
{
    scalingTests(100000, 8000, 10); // 1M max size, 8k step, average over 10 runs
    return 0;
}