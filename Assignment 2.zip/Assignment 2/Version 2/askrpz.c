#include "askrpz.h"


RBST initRBST() 
{
    #ifdef DEBUG //Checks for debugging setting
    {
        printf("DEBUG: Initializing RBST in initRBST...\n"); 
    }
    #endif //Ends debugging exclusive code
	
    RBST tree = (RBST)malloc(sizeof(*tree)); 
	//Allocates memory for a new RBST and assign the memory address to the 'tree' variable
	
    if (!tree) //Checks if memory allocation was successful (tree will be NULL if it failed)
    {
        #ifdef DEBUG //Checks for debugging "setting"
        {
            printf("DEBUG: Memory allocation error in initRBST...\n");
        }
        #endif //Ends debugging exclusive code
		
        exit(1); //Terminates the program with an error code '1' due to memory allocation failure
    }
	
    tree -> root = NULL; //Initializes the root of the newly created tree to NULL (an empty tree)
	
    #ifdef DEBUG //Checks for debugging "setting"
    {
        printf("DEBUG: RBST initialized.\n"); 
    }
    #endif //Ends debugging exclusive code
		
    return tree; //Returns the pointer to the initialized RBST
}


Node* createNode(int key) 
{
    #ifdef DEBUG //Checks for debugging setting
    {
        printf("DEBUG: Creating node with key in createNode: %d\n", key); 
    }
    #endif //Ends debugging exclusive code
	
    Node* newNode = (Node*)malloc(sizeof(Node)); 
	//Allocates memory for a new node and assigns the memory address to the 'newNode' variable
	
    if(!newNode) //Checks if memory allocation was successful (newNode will be NULL if it failed)
    {
        #ifdef DEBUG //Checks for debugging setting
        {
            printf("DEBUG: Memory allocation error in createNode...\n");
        }
        #endif //Ends debugging exclusive code
		
        exit(1); //Terminates the program with an error code '1' due to memory allocation failure
    }
	
    newNode -> key = key; //Sets the key of the new node with the provided value
    newNode -> left = NULL; //Initializes the left child of the new node to NULL (no left child)
    newNode -> right = NULL; //Initializes the right child of the new node to NULL (no right child)
    return newNode; //Returns the pointer to the newly created node
}


int _insertNode(Node** node, int key, int nodesVisited) 
{
    if (*node == NULL)  //Checks if the current node is NULL (meaning it's an empty spot)
	{
		#ifdef DEBUG //Checks for debugging setting
		{
			printf("DEBUG: In _insertNode, inserting %d. No node found, creating a new one.\n", key); 
		}
		#endif //Ends debugging exclusive code
		
        *node = createNode(key); //Creates a new node with the given key and assigns it to the current position
        return nodesVisited + 1; //Returns the incremented count of visited nodes
    }

    nodesVisited++; //Increments the nodesVisited count since the current node is visited

    if (key < (*node) -> key)  //Checks if the given key is less than the key of the current node
	{
		#ifdef DEBUG //Checks for debugging setting
		{
			printf("DEBUG: In _insertNode, Inserting %d. Going left from %d.\n", key, (*node) -> key); 
		}
		#endif //Ends debugging exclusive code
		
        //Inserts the new key into the left subtree and returns the updated count of visited nodes
        return _insertNode(&((*node) -> left), key, nodesVisited);
    } 
	
	else if (key > (*node) -> key)  //Checks if the given key is greater than the key of the current node
	{
		#ifdef DEBUG //Checks for debugging setting
		{
			printf("DEBUG: In _insertNode, Inserting %d. Going right from %d.\n", key, (*node) -> key); 
		}
		#endif //Ends debugging exclusive code
		
        //Inserts the new key into the right subtree and returns the updated count of visited nodes
        return _insertNode(&((*node) -> right), key, nodesVisited);
    }

	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In _insertNode, Key %d already exists. Not inserting.\n", key); 
	}
	#endif //Ends debugging exclusive code
	
/*     
		If the key is neither less than nor greater than the current node's key, it means the key already exists. 
        The function then simply returns the count of visited nodes.
*/
    return nodesVisited;
}


int insertRBST(RBST tree, int key) 
{
	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In insertRBST, inserting key %d into RBST...\n", key);
		
	}
	#endif //Ends debugging exclusive code
	
/*
		Calls the internal "_insertNode" function to insert the key into the RBST.
		It starts at the root of the tree and initiates the count of visited nodes as 0.
*/
    return _insertNode(&(tree -> root), key, 0);
}


int _freeNodes(Node* node) 
{
    if (node == NULL) //Checks if the node is NULL (base case for recursive function)
	{
        return 0; //If the node is NULL, it returns 0, indicating no node was freed
    }
	
	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In _freeNodes, freeing node with key: %d\n", node -> key);
		
	}
	#endif //Ends debugging exclusive code
	
    //Recursively frees the left subtree and counts the number of nodes freed in the process
    int leftVisits = _freeNodes(node -> left);
    
    //Recursively frees the right subtree and counts the number of nodes freed in the process
    int rightVisits = _freeNodes(node -> right);
    
    free(node); //Frees the current node's memory

    //Returns the total number of nodes freed (left + right + current node)
    return leftVisits + rightVisits + 1;
}


int freeRBST(RBST tree) 
{
	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In freeRBST, freeing entire RBST...\n");
		
	}
	#endif //Ends debugging exclusive code
	
    //Calls the _freeNodes function to free each node in the RBST and get the total count of nodes freed
    int totalNodes = _freeNodes(tree -> root);

    free(tree); //Frees the memory allocated for the RBST itself

	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In freeRBST, freed RBST.\n");
		
	}
	#endif //Ends debugging exclusive code
	
    return totalNodes; //Returns the total number of nodes that were freed
}


void inOrderTraversal(Node* root, int* arr, int* index) 
{
    if (root == NULL) return; //Base condition: If the node is NULL, exit the function
    
    //Traverse the left subtree first (left child of the current node)
    inOrderTraversal(root -> left, arr, index);

	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In inOrderTraversal, recording key %d during InOrder traversal...\n", root -> key);
		
	}
	#endif //Ends debugging exclusive code
	
    //Store the key of the current node into the array at the current index
    arr[(*index)++] = root -> key;

    //Traverse the right subtree next (right child of the current node)
    inOrderTraversal(root -> right, arr, index);
}


void shuffleArray(int* arr, int size) 
{
	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In shuffleArray, shuffling array...\n");
		
	}
	#endif //Ends debugging exclusive code
	
    //Seed the random number generator using the current system time
    srand(time(0));
    
    //Iterate over each element in the array, starting from the last element
    for (int i = size - 1; i > 0; i--) {
        //Randomly select an index between 0 and i (inclusive)
        int j = rand() % (i + 1);

        //Swap the elements at positions i and j
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

	#ifdef DEBUG //Checks for debugging setting
	{
		printf("DEBUG: In shuffleArray, finished shuffling...\n");
		
	}
	#endif //Ends debugging exclusive code
}


int testInsertRBST(int n, int *keys) 
{
    RBST tree = initRBST(); //Initializes an empty RBST
    int totalVisited = 0; //Variable to keep track of total number of nodes visited

    //Iterates over each key and insert it into the RBST
    for(int i = 0; i < n; i++) 
	{
        //Inserts key into the tree and accumulate the number of nodes visited during the insertion
        totalVisited += insertRBST(tree, keys[i]);
    }

/*
	After all keys have been inserted, frees the entire tree
    and adds the number of nodes visited during the free operation to the total
*/
    totalVisited += freeRBST(tree);
    
    //Returns the total number of nodes visited during the test
    return totalVisited;
}


int testFreeRBST(int n, int* keys) 
{
    RBST tree = initRBST(); //Initializes an empty RBST

    //Iterates over each key to insert it into the RBST
    for (int i = 0; i < n; i++) 
	{
        insertRBST(tree, keys[i]); //Inserts the current key into the tree
    }
	
/*
	After all keys have been inserted, free the entire tree
    The function returns the number of nodes visited during the free operation
*/

    return freeRBST(tree);
}


void scalingTests(int max_size, int step, int runs) 
{
    srand(time(0)); //Seeds the random number generator based on the current time

    printf("Size, Avg Insert Visits, Avg Free Visits\n"); 

    //Loops over different tree sizes to conduct the scaling tests
    for (int size = step; size <= max_size; size += step) 
	{
        //Allocates memory for the array of keys of the current size
        int *keys = malloc(size * sizeof(int));
        
        //Checks for successful memory allocation
        if (!keys) 
		{
            #ifdef DEBUG //Checks for debugging setting
			{
				
				printf("DEBUG: Memory allocation error in scalingTests...\n");
			}
			#endif //Ends debugging exclusive code
			
            return; //Terminates the function if memory allocation failed
        }

        //Generates random keys for the current size
        for (int i = 0; i < size; i++) 
		{
            keys[i] = rand();
        }

        int totalInsertVisits = 0; //Counter for total node visits during insert operations
        int totalFreeVisits = 0;  //Counter for total node visits during free operations

        //Conducts the tests multiple times (as specified by 'runs') to obtain averaged results
        for (int i = 0; i < runs; i++) 
		{
            totalInsertVisits += testInsertRBST(size, keys); //Tests and accumulates node visits during insertion
            totalFreeVisits += testFreeRBST(size, keys);    //Tests and accumulates node visits during freeing
        }

        //Prints the averaged results for the current tree size
        printf("%d, %f, %f\n", size, (double)totalInsertVisits / runs, (double)totalFreeVisits / runs);

        free(keys); //Frees the allocated memory for the array of keys
    }
}




