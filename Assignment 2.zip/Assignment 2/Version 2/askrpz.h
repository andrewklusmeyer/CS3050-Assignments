#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct Node 
{
    int key;
    struct Node* left;
    struct Node* right;
} Node;

typedef struct 
{
    Node* root;
} *RBST;

RBST initRBST();
Node* createNode(int key);
int _insertNode(Node** node, int key, int nodesVisited);
int insertRBST(RBST tree, int key);
int _freeNodes(Node* node);
int freeRBST(RBST tree);
void inOrderTraversal(Node* root, int* arr, int* index);
void shuffleArray(int* arr, int size);
int testInsertRBST(int n, int *keys);
int testFreeRBST(int n, int* keys);
void scalingTests(int max_size, int step, int runs);
