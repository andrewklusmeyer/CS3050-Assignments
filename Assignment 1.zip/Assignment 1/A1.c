#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <sys/time.h>


int obtainRandomSample(int *sequence)
{
	#ifdef DEBUG //Checks for debug "setting"
	{
		printf("DEBUG: Entered into function obtainRandomSample...\n");
	}
	#endif //Ends debugging exclusive code

    int counter = 0; //Initializes a counter variable to 0
    int current = 0; //Intializes a current variable to store the selected value
	
	

struct timeval currentTime; //Declares a struct timeval variable to store time information

gettimeofday(&currentTime, NULL); //Gets the current time and store it in the currentTime variable

clock_t start = clock(); //Declare a start variable of type clock_t to store clock ticks


/*
	Enters a loop that continues until the current clock time is 5 ticks greater than start.
	This will act as a small delay and ensure randomness
*/ 

while(clock() < start + 5){};

//Seeds the srand48 with a combination of seconds and microseconds from currentTime
srand48(currentTime.tv_usec + currentTime.tv_sec);


    while(sequence[counter] != INT_MAX) //Loops until the element in the array is INT_MAX.
    {
		#ifdef DEBUG //Checks for debug "setting"
		{
			printf("DEBUG: Entered while loop in obtainRandomSample...\n");
		}
		#endif //Ends debugging exclusive code
		
/*
		Generates a random double between 0 and 1 using drand48().
        If this random value is less than or equal to 1 divided by (counter + 1),
        it assigns the value at sequence[counter] to the current variable.
*/
        if(drand48() <= 1 / ((double)counter + 1))
        {
            current = sequence[counter];
			
			#ifdef DEBUG //Checks for debug "setting"
			{
				printf("DEBUG: Current variable in obtainRandomSample = %d...\n",current);
				printf("DEBUG: Counter variable in obtainRandomSample = %d...\n",counter);
			}
			#endif //Ends debugging exclusive code
			
        }
        

        counter++; //Increments the counter
    }
    
    
    return current; //Return the last selected value stored in current
	
}



int testRandomSample()
{
	#ifdef DEBUG //Checks for debug "setting"
	{
		printf("DEBUG: Entered testRandomSample function...\n");
		printf("DEBUG: Now attempting to open A1_Values.txt in testRandomSample...\n");
	}
	#endif //Ends debugging exclusive code

	FILE *filePointer = fopen("A1_Values.txt", "r"); //Opens the file A1_Values.txt in read mode
	if (filePointer == NULL) //Checks if the file couldn't be opened
	{
		return 1; //Returns an error code of 1

		#ifdef DEBUG //Checks for debug "setting"
		{
			printf("DEBUG: A1_Values.txt was unable to be opened in testRandomSample...\n"); 
			printf("DEBUG: Returning an error code of 1 from testRandomSample...\n"); 
		}
		#endif //Ends debugging exclusive code
	}
	else
	{
		#ifdef DEBUG //Checks for debug "setting"
		{
			printf("DEBUG: A1_Values.txt successfully opened...\n"); 
		}
		#endif //Ends debugging exclusive code
	}

	int randomInteger = 0; //Initializes a variable to store integers from the file
	int tempArray[26]; //Creates an array to store integers from the file
	int counter = 0; //Initializes a counter variable to keep track of the number of integers read

	while (randomInteger != INT_MAX) //Loops through all integers
	{
/*		#ifdef DEBUG
		{
			printf("DEBUG: Attempting to retrieve value from A1_Values.txt...\n");
		}
		#endif
*/

		fscanf(filePointer, "%d", &randomInteger); //Reads an integer from the file and store it in randomInteger
		tempArray[counter] = randomInteger; //Stores the read integer in the tempArray
		counter++; //Increments the counter to keep track of the number of integers read
	}

	fclose(filePointer); //Closes the file

	int result = obtainRandomSample(tempArray); //Calls obtainRandomSample and assigns the result to result variable

	return result;
}



int main(void)
{

/*
Creates and initializes counter variables to keep track
of how many times each variable is selected
*/

	int countNeg45 = 0;
	int count73 = 0;
	int count12 = 0;
	int countNeg88 = 0;
	int count67 = 0;
	int count41 = 0;
	int count96 = 0;
	int countNeg11 = 0;
	int countNeg34 = 0;
	int count58 = 0;
	int countNeg100 = 0;
	int countNeg53 = 0;
	int countNeg76 = 0;
	int count20 = 0;
	int count82 = 0;
	int count64 = 0;
	int countNeg25 = 0;
	int count5 = 0;
	int count39 = 0;
	int countNeg68 = 0;
	int countNeg92 = 0;
	int count17 = 0;
	int count31 = 0;
	int countNeg69 = 0;
	int countNeg9 = 0;


	int amountOfTests = 50000; //Creates and initializes variables stating how many tests you want to do
	for(int i = 0; i < amountOfTests; i++) //Begins running tests
	{
		int tempResult = testRandomSample();
//		printf("Random Integer Obtained: %d...\n",tempResult);
		
/*
		Determines which number was chosen 
		at random and adds 1 to the corresponding counter variable 
*/
		
		switch(tempResult)
		{
			case -45:
			
				countNeg45++;
				
			break;
			
			
			case 73:
			
				count73++;
				
			break;
			
			
			case 12:
			
				count12++;
				
			break;
			
			
			case -88:
			
				countNeg88++;
				
			break;
			
			
			case 67:
			
				count67++;
				
			break;
			
			
			case 41:
			
				count41++;
				
			break;
			
			
			case 96:
			
				count96++;
				
			break;
			
			
			case -11:
			
				countNeg11++;
				
			break;
			
			
			case -34:
			
				countNeg34++;
			
			break;
			
			
			case 58:
			
				count58++;
				
			break;
			
			
			case -100:
			
				countNeg100++;
				
			break;
			
			
			case -53:
			
				countNeg53++;
				
			break;
			
			
			case -76:
			
				countNeg76++;
				
			break;
			
			
			case 20:
			
				count20++;
				
			break;
			
			
			case 82:
			
				count82++;
				
			break;
			
			
			case 64:
			
				count64++;
				
			break;
			
			
			case -25:
			
				countNeg25++;
				
			break;
			
			
			case 5:
			
				count5++;
				
			break;
			
			
			case 39:
			
				count39++;
				
			break;
			
			
			case -68:
			
				countNeg68++;
				
			break;
			
			
			case -92:
			
				countNeg92++;
				
			break;
			
			
			case 17:
			
				count17++;
			
			break;
			
			
			case 31:
			
				count31++;
				
			break;
			
			
			case -69:
			
				countNeg69++;
				
			break;
			
			
			case -9:
			
				countNeg9++;
				
			break;
			
		}
	}
			
	
	
	printf("\n\t***RESULTS OF %d TESTS***\n\n",amountOfTests);
	printf("\tAmount of -45's: %d\n",countNeg45);
	printf("\tAmount of 73's: %d\n",count73);
	printf("\tAmount of 12's: %d\n",count12);
	printf("\tAmount of -88's: %d\n",countNeg88);
	printf("\tAmount of 67's: %d\n",count67);
	printf("\tAmount of 41's: %d\n",count41);
	printf("\tAmount of 96's: %d\n",count96);
	printf("\tAmount of -11's: %d\n",countNeg11);
	printf("\tAmount of -34's: %d\n",countNeg34);
	printf("\tAmount of 58's: %d\n",count58);
	printf("\tAmount of -100's: %d\n",countNeg100);
	printf("\tAmount of -53's: %d\n",countNeg53);
	printf("\tAmount of -76's: %d\n",countNeg76);
	printf("\tAmount of 20's: %d\n",count20);
	printf("\tAmount of 82's: %d\n",count82);
	printf("\tAmount of 64's: %d\n",count64);
	printf("\tAmount of -25's: %d\n",countNeg25);
	printf("\tAmount of 5's: %d\n",count5);
	printf("\tAmount of 39's: %d\n",count39);
	printf("\tAmount of -68's: %d\n",countNeg68);
	printf("\tAmount of -92's: %d\n",countNeg92);
	printf("\tAmount of 17's: %d\n",count17);
	printf("\tAmount of 31's: %d\n",count31);
	printf("\tAmount of -69's: %d\n",countNeg69);
	printf("\tAmount of -9's: %d\n\n",countNeg9);


	return 0;

}
