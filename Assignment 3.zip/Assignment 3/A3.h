#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <float.h>
#include <time.h>

typedef struct bucket
{
    float min;
    float max;
} Bucket;

Bucket* makeBucketArray(int arraySize);
void assignBucket(Bucket* bucketArray, float* dataArray, int arraySize, float minValue, float maxValue);
float* removeMinAndMax(float array[], int arraySize, float* minValue, float* maxValue);
float findClusterExtreme(float array[], int n);
void fillRandom(float array[], int n);
void testScaling();


