#include "A3.h"


//Function to create an array of Bucket structures with dynamic memory allocation
Bucket* makeBucketArray(int arraySize)
{
    //Allocates memory for array of Bucket structures with one extra Bucket
    Bucket* bucketArray = malloc((arraySize + 1) * sizeof(Bucket));
	
    //Checks if memory allocation failed
    if(bucketArray == NULL)
    {
        //If in DEBUG mode, print debug message
        #ifdef DEBUG
        {
            printf("DEBUG: Malloc failed in makeArray...\n");
        }
        #endif

        //If allocation failed, return NULL
        return NULL;
    }

    //Initializes the min and max values of all Buckets to max and min float values
    for(int i = 0; i < (arraySize); i++)
    {
        bucketArray[i].min = FLT_MAX;
        bucketArray[i].max = FLT_MIN;
    }

    //Returns the pointer to the allocated array of Buckets
    return bucketArray;
}

//Function to assign values from dataArray to the appropriate buckets in bucketArray
void assignBucket(Bucket* bucketArray, float* dataArray, int arraySize, float minValue, float maxValue)
{
    int index = 0; //Initializes bucket index

    //Loops over each element in dataArray
    for(int i = 0; i < arraySize; i++)
    {
        //Calculates bucket index based on the value distribution
        index = (int) (((dataArray[i] - minValue) / (maxValue - minValue)) * (arraySize - 1));

        //If current data value is less than the current min of the bucket, update it
        if(dataArray[i] < bucketArray[index].min)
        {
            bucketArray[index].min = dataArray[i];
        }

        //If current data value is greater than the current max of the bucket, update it
        if(dataArray[i] > bucketArray[index].max)
        {
            bucketArray[index].max = dataArray[i];
        }
    }
}

//Function to remove the minimum and maximum values from an array
float* removeMinAndMax(float array[], int arraySize, float* minValue, float* maxValue)
{
    //If array size is 2 or less, there's nothing to remove, return NULL
    if (arraySize <= 2)
    {
		//If in DEBUG mode, print debug message
		#ifdef DEBUG
		{
			printf("DEBUG: Invalid array size in removeMinAndMax...\n");
		}
		#endif
		
        return NULL;
    }

    //Finds initial min and max in the array
    float tempMin = array[0];
    float tempMax = array[0];
	
    //Allocates memory for new array with size two less than input array
    float* tempArray = malloc((arraySize - 2) * sizeof(float));

    //If allocation failed, return NULL
    if (tempArray == NULL)
    {
        return NULL;
    }

    //Finds actual min and max values in the array
    for (int i = 0; i < arraySize; i++) 
    {
        if (array[i] < tempMin)
        {
            tempMin = array[i];
        }

        if (array[i] > tempMax)
        {
            tempMax = array[i];
        }
    }

    int index = 0, tempIndex = 0; //Initializes indices

    //Loops through original array to copy elements except for min and max into tempArray
    while (index < arraySize) 
    {
        if (array[index] != tempMin && array[index] != tempMax)
        {
            tempArray[tempIndex++] = array[index];
        }

        index++;
    }

    //Sets the minValue and maxValue pointers to the found minimum and maximum values
    *minValue = tempMin;
    *maxValue = tempMax;

    //Returns the pointer to the new array without the min and max elements
    return tempArray;
}

//Function to find the largest gap between clusters
float findClusterExtreme(float array[], int n)
{
    float minValue, maxValue;
	
    //Removes min and max from the array and get the new array without them
    float* tempArray = removeMinAndMax(array, n, &minValue, &maxValue);

    //Creates a bucket array for n-2 elements
    Bucket* bucketArray = makeBucketArray(n - 2);
	
    //Assigns the elements of tempArray to buckets
    assignBucket(bucketArray, tempArray, n - 2, minValue, maxValue);

    float largestGap = 0.0; //Variable to store the largest gap
    float gapStart = minValue; //Variable to store the start of the largest gap

    //Finds the largest gap between clusters
    for(int i = 0; i < n - 2; i++)
    {
        //If the gap before the current bucket's min is greater than the current largest gap, update it
        if(bucketArray[i].min - gapStart > largestGap)
        {
            largestGap = bucketArray[i].min - gapStart;
        }

        //If the current bucket has a max value, update the start of the gap to be the max value
        if(bucketArray[i].max != FLT_MIN)
        {
            gapStart = bucketArray[i].max;
        }
    }

    //Checks if the gap after the last bucket's max is larger than the current largest gap
    if(maxValue - gapStart > largestGap)
    {
        gapStart = maxValue - largestGap;
    }

    //Frees the memory allocated for tempArray and bucketArray
    free(tempArray);
    free(bucketArray);

    //Returns the start of the largest gap
    return gapStart;
}

//Function to fill an array with random float values
void fillRandom(float array[], int n) 
{
    for (int i = 0; i < n; i++) 
	{
        array[i] = ((float)rand()/(float)(RAND_MAX)) * n;
    }
}

void testScaling() 
{
    //Opens a file to store the results
    FILE *fp = fopen("scaling_results.csv", "w");
    if (fp == NULL) 
	{
        printf("Failed to open file for writing.\n");
        return;
    }

    //Writes the header for the CSV file
    fprintf(fp, "Elements, AverageRuntime, O(nlogn), O(n^2)\n");

    clock_t start, end;
    double cpu_time_used, sum_time, avg_time;
    int runs = 5; //Number of runs to average the runtime

    for (int n = 1000; n <= 512000; n *= 2) 
	{
        sum_time = 0.0;

        //Runs multiple tests and average the results
        for (int i = 0; i < runs; i++) 
		{
            float *array = malloc(n * sizeof(float));

            if (array == NULL) 
			{
				#ifdef DEBUG
				{
					printf("DEBUG: Memory allocation failed at size %d in testScaling...\n", n);
				}
				#endif
				
                continue;
            }

            fillRandom(array, n); //Fills the array with random numbers

            start = clock();
            findClusterExtreme(array, n); 
            end = clock();

            cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
            sum_time += cpu_time_used;

            free(array);
        }

        avg_time = sum_time / runs;
        double o_n_log_n = avg_time * log(n) / n; //Scale to compare against O(n log(n))
        double o_n_squared = avg_time * n; //Scale to compare against O(n^2)

        //Writes the results to the file
        fprintf(fp, "%d, %f, %f, %f\n", n, avg_time, o_n_log_n, o_n_squared);
    }

    fclose(fp); //Closes the file after writing all the results
}

/*********************************************************************

int main(void) 
{
    int n;
	
    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    //Allocates memory for the array based on user input for the number of elements
    float* array = malloc(n * sizeof(float));
	
    //If memory allocation fails, print an error message and return 1 (indicating error)
    if (array == NULL) 
    {
		#ifdef DEBUG
		{
			printf("DEBUG: Memory allocation failed in main...\n");
		}
		#endif
		
        return 1;
    }

    //Prompts the user to enter the elements of the array
    printf("Enter the %d elements:\n", n);
	
    //Reads each element into the array
    for (int i = 0; i < n; i++) 
    {
        scanf("%f", &array[i]);
    }

    //Prints the input array to the user
    printf("Input Array:\n");
    for (int i = 0; i < n; i++) 
    {
        printf("%f ", array[i]);
    }
    printf("\n");

    //Calls the function to find the result and store it
    float result = findClusterExtreme(array, n);
	
    //Prints the result to the user
    printf("The result of findClusterExtreme is: %f\n", result);
	
    //Frees the memory allocated for the array
    free(array);
	
	//Executes the scalability test
    testScaling();
	
    return 0;
}

*********************************************************************/
